package pgv.examenpgv;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Jonathan
 */
public class Main {

    public static void main(String[] args) {
        String sistema_operativo = System.getProperty("os.name").toLowerCase();
        String comando = GetCommand(sistema_operativo);
        if (comando.equals("Invalido")) {
            System.out.println("No se ha podido encontrar el sistema operativo");
        } else {
            try {
            // Creamos el proceso con el comando previamente elegido
            Process proceso = Runtime.getRuntime().exec(comando);
            BufferedReader reader = new BufferedReader(new InputStreamReader(proceso.getInputStream()));
            String linea_comando;
            StringBuilder output = new StringBuilder();
            // Metemos el resultado del comando en una string 
            while ((linea_comando = reader.readLine()) != null) {
                output.append(linea_comando).append(System.lineSeparator());
            }
            // Imprimos esa String y la guardamos en un txt
            System.out.println(output);
            try (FileWriter writer = new FileWriter("Sysinfo.txt")) {
                writer.write(output.toString());
                System.out.println("Información guardada en Sysinfo.txt");
            }
            } catch (IOException e) {
                System.out.println("Ocurrio un error de entrada/Salida: " + e.getMessage());
            }
        }
        
    }

    // Función que nos devolverá el comando correspondiente según el sistema operativo
    private static String GetCommand(String sistema_operativo) {
        if (sistema_operativo.contains("win")) {   
            return "systeminfo";
        } else if (sistema_operativo.contains("nix") || sistema_operativo.contains("nux") || sistema_operativo.contains("mac")) {
            return "uname -a";
        } else {
            System.out.println("Sistema operativo no detectado.");
            return "Invalido";
        }
    }
}









































